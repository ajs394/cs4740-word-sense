import subprocess
import os

class Learn:

    def __init__(self):
        return

    def learn_file(self, filename):
        subprocess.check_output("java -Xmx512m -cp .;lib/weka.jar Learn train ../new_arffs/"+filename+".train.arff ../Classifiers/"+filename+"_classifier.serialized")
        subprocess.check_output("java -Xmx512m -cp .;lib/weka.jar Learn test ../Classifiers/"+filename+"_classifier.serialized ../new_arffs/"+filename+".test.arff ../Outputs/"+filename+"_output.txt")

    def learn(self):
        for r,d,f in os.walk("../new_arffs"):
            for files in f:
                if files.endswith("train.arff"):
                    self.learn_file(files.title()[0:-11])

    def run(self):
        self.learn()
